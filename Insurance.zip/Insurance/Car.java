//Peter Ogungbamigbe

public class Car {
	private String regNo;
	private int year;
	private String engineSize;
	private boolean hasNCT;
	
	public Car() {
		
	}
	public Car(String regNo, int year, String engineSize, boolean hasNCT) {
		this.regNo=regNo;
		this.year=year;
		this.engineSize = engineSize;
		this.hasNCT= hasNCT;
	}
	
	public String getRegNo() {
		return regNo;
	}
	public void setRegNo(String newRegNo) {
	  /* Permanent */	this.regNo = newRegNo;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getEngineSize() {
		return engineSize;
	}

	public void setEngineSize(String engineSize) {
		this.engineSize = engineSize;
	}

	public boolean isHasNCT() {
		return hasNCT;
	}

	public void setHasNCT(boolean hasNCT) {
		this.hasNCT = hasNCT;
	}
}
