//Peter Ogungbamigbe

public class Policy {


	private String policyID;
	private int premium;
	private int numberOfClaims;
	private Driver driver;
	private Car car;
	
	public Policy() {
		
	}
	
	public Policy(String policyID, int premium, int numberOfClaims, Driver driver, Car car) {
		super();
		this.policyID = policyID;
		this.premium = premium;
		this.numberOfClaims = numberOfClaims;
		this.driver = driver;
		this.car = car;
	}

	public String getPolicyID() {
		return policyID;
	}

	public void setPolicyID(String policyID) {
		this.policyID = policyID;
	}

	public int getPremium() {
		return premium;
	}

	public void setPremium(int premium) {
		this.premium = premium;
	}

	public int getNumberOfClaims() {
		return numberOfClaims;
	}

	public void setNumberOfClaims(int numberOfClaims) {
		numberOfClaims = numberOfClaims;
	}

	public Driver getDriver() {
		return driver;
	}

	public void setDriver(Driver driver) {
		this.driver = driver;
	}

	public Car getCar() {
		return car;
	}

	public void setCar(Car car) {
		this.car = car;
	}


	
	
}