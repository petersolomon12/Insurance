//Peter Ogungbamigbe

public class Driver {
	private String drivingLicence;
	private String name;
	private int points;
	private String number;
	
	
	
	public Driver() {
		
	}



	public Driver(String drivingLicence, String name, int points, String number) {
		super();
		this.drivingLicence = drivingLicence;
		this.name = name;
		this.points = points;
		this.number = number;
	}



	public String getDrivingLicence() {
		return drivingLicence;
	}



	public void setDrivingLicence(String drivingLicence) {
		this.drivingLicence = drivingLicence;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public int getPoints() {
		return points;
	}



	public void setPoints(int points) {
		this.points = points;
	}



	public String getNumber() {
		return number;
	}



	public void setNumber(String number) {
		this.number = number;
	}
	
}
