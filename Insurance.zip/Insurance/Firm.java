//Peter Ogungbamigbe
import java.util.ArrayList;

public class Firm {
	private ArrayList<Driver> drivers = new ArrayList<Driver>();
	private ArrayList<Car> cars = new ArrayList<Car>();
	private ArrayList<Policy> policies = new ArrayList<Policy>();
	
	//Constructor
	public Firm() {
		createCar("151D7897", 2015, "1.6", true);
		createCar("161D1564", 2021, "1.2", true);
		createCar("06C456", 2015, "1.0", false);
		createDriver("P87845", "Peter Solomon", 3, "0899645768");
		createDriver("P87565", "Steve Solomon", 6, "087564512");
		createDriver("P87556", "Ben Solomon", 0, "0899745698");
		createPolicy(drivers.get(1), cars.get(1), "P20", 400, 5);
		createPolicy(drivers.get(2), cars.get(2), "P21", 600, 1);
		System.out.println("Total premiums " +totalPremiums());
		increasePremium();
		System.out.println("Total premiums " +totalPremiums());
		System.out.println("Total claims " +totalClaims());



		
	}
	
	public void createCar(String regNo, int year, String engineSize, boolean hasNCT) {
		Car car = new Car(regNo, year, engineSize, hasNCT);
		cars.add(car);
	}
	
	public void createDriver(String drivingLicence, String name, int points, String number) {
		Driver driver = new Driver(drivingLicence,name,points,number);
		drivers.add(driver);
	}
		
		public void createPolicy(Driver driver, Car car, String policyId, int premium,int numberOfClaims)
		{
		if(driver.getPoints()<12) {
			if(car.isHasNCT()) {
				Policy policy = new Policy(policyId, premium,numberOfClaims, driver, car);
				policies.add(policy);
				System.out.println("Policy created for " + car.getRegNo());
			}else {
				System.out.println("Sorry, " +driver.getName()+ " the car has no BCT so no policy for you.");
			}
		}
		else {
			System.out.println("Sorry, " + driver.getName()+ " you have 12 or more points. ");
		}
	}
		
	public void deletePolicy(Policy policy) {
		policies.remove(policy);
	}
	public void increasePremium() {
		for(Policy policy: policies) {
			int currentPremium = policy.getPremium();
			int newPremium= currentPremium + (currentPremium + 100);
			policy.setPremium(newPremium);
		}
		System.out.println("Premiums increased");
	}
	public int totalClaims() {
		int totalClaims =0;
		for(Policy policy : policies) {
			totalClaims = totalClaims + policy.getNumberOfClaims();
	
		}
		return totalClaims;
	}
	public int totalPremiums() {
		int totalPremiums =0;
		for(Policy policy:policies) {
			totalPremiums= totalPremiums + policy.getPremium();
		}
		return totalPremiums;
	}
	
	public static void main(String[] args) {
		Firm firm = new Firm();
	}
}
